package com.company;

public class Square extends Rectangle {
    public Square(double firstSide, double secondSide, double heigh) {
        super(firstSide, secondSide, heigh);
    setName("квадрат: ");

    }

    @Override
    public double getPerimeter() {
        return 4 * getFirstSide() ;

    }

    @Override
    public double getSquare() {
        return Math.pow(getFirstSide(),2) ;
    }

    @Override
    public String toString() {
        String result = this.getName() +"\n";
        result += "Сторона: " + getFirstSide();
        result += " периметр: " + this.getPerimeter() + "\n";
        result += "площадь: " + this.getSquare() + "\n";

        return result;
    }
}
