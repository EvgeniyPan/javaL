package com.company;

import com.company.Shape1;

public class Parallelogram extends Shape1 {

    private double firstSide;
    private double secondSide;
    private double heigh;
  //для чего это сделали?
    public Parallelogram( double firstSide,double secondSide, double heigh) {
        super("параллелограмм: ");
        this.firstSide = firstSide;
        this.secondSide = secondSide;
        this.heigh = heigh;
    }

    @Override
    public double getPerimeter() {
        return 2 * (firstSide+secondSide);
    }

    @Override
    public double getSquare() {
        return firstSide * heigh;
    }

    @Override
    public String toString() {
        String result  = this.getName() + "\n";
                result += "стороны: " + firstSide + " , " + secondSide + "\n";
                result += "высота: " + heigh + "\n";
                result += "периметр: " + this.getPerimeter() + "\n";
                result += "площадь: " + this.getSquare() + "\n";
                return result;
    }
    public double getFirstSide () {return firstSide;}
    public double getSecondSide () {return secondSide;}
    public double getHeigh () {return heigh;}


}
