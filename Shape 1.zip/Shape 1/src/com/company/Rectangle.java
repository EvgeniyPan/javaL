package com.company;

public class Rectangle extends Parallelogram {
    public Rectangle(double firstSide, double secondSide, double heigh) {
        super(firstSide, secondSide, heigh);
        setName("прямоугольник: ");
           }

    @Override
    public double getPerimeter() {
        return  2* (getFirstSide()+getSecondSide());             //почему при генерации выдает вот это - super.getPerimeter();?
    }

    @Override
    public double getSquare() {
        return getFirstSide() * getSecondSide();
    }

    @Override
    public String toString() {
        String result = this.getName() + "\n";
        result += "стороны: " + getFirstSide() + " , " +  getSecondSide() + "\n";
        result += "периметр: " + getPerimeter() + "\n";
        result += "площадь: " + getSquare() + "\n";

        return result;
    }
}
