package com.company;

public abstract class Shape1 {
    public Shape1 (String name){
        this.name = name;
    }
    private String name;

    public abstract double getPerimeter ();

    public abstract double getSquare();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}


