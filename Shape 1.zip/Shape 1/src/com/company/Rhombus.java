package com.company;

public class Rhombus extends Parallelogram {

    public Rhombus(double side, double firstDiagonal, double secondDiagonal) {
        super(side, firstDiagonal, secondDiagonal);
        setName("Ромб: ");}

        @Override
        public double getPerimeter() {
            return getFirstSide() * 4;
        }

        @Override
        public double getSquare() {
            return getSecondSide()*getHeigh();
        }

    @Override
    public String toString() {
        String result = this.getName() + "\n";
        result += "стороны: " + getFirstSide() + "\n";
        result += "диагонали: " + getSecondSide() + " , " + getHeigh() + "\n";
        result += "периметр: " + this.getPerimeter() + "\n";
        result += "площадь: " + this.getSquare() + "\n";
        return result;


    }
}
