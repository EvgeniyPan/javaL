package com.company;

public class Main {

    public static void main(String[] args) {
        Shape1 [] shapes = new Shape1[4];
      shapes [0] = new Parallelogram (5, 6,3);
         shapes [1] = new Rhombus(1.8, 3,4);
        shapes [2] = new Rectangle(6,4,0);
        shapes [3] = new Square(4, 0,0);
        for (Shape1 shape : shapes) {
            System.out.println(shape.toString());
        }
    }
}
